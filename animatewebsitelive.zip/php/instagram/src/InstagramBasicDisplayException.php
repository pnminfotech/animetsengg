<?php

namespace EspressoDev\InstagramBasicDisplay;

class InstagramBasicDisplayException extends \Exception
{
    // ..
}
